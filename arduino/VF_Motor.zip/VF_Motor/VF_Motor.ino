const int pwmPin1 = 9;
const int pwmPin2 = 10;
const int pwmPin3 = 11;
const int botonPin = 2;

const int numSamples = 167;
const int pwmMax = 255;

uint8_t sineTable[numSamples];
bool sentidoHorario = true;   // Dirección inicial
bool esperandoRebote = false;

void setup() {
  pinMode(pwmPin1, OUTPUT);
  pinMode(pwmPin2, OUTPUT);
  pinMode(pwmPin3, OUTPUT);
  pinMode(botonPin, INPUT);  // Pull-down externo

  for (int i = 0; i < numSamples; i++) {
    float angle = 2 * PI * i / numSamples;
    float sineValue = sin(angle); // de -1 a 1
    sineTable[i] = (uint8_t)((sineValue + 1) * 127.5); // Escalar a 0–255
  }
}

void loop() {
  // Leer botón con detección de flanco
  if (digitalRead(botonPin) == HIGH && !esperandoRebote) {
    esperandoRebote = true;

    //  Etapa de frenado suave
    for (int amp = 255; amp >= 0; amp -= 5) {
      for (int i = 0; i < numSamples; i++) {
        int index1 = i;
        int index2 = (i + numSamples / 3) % numSamples;
        int index3 = (i + 2 * numSamples / 3) % numSamples;

        analogWrite(pwmPin1, (sineTable[index1] * amp) / 255);
        analogWrite(pwmPin2, (sineTable[index2] * amp) / 255);
        analogWrite(pwmPin3, (sineTable[index3] * amp) / 255);

        delayMicroseconds(100);
      }
    }

    // Apagar PWM
    analogWrite(pwmPin1, 0);
    analogWrite(pwmPin2, 0);
    analogWrite(pwmPin3, 0);

    delay(500); // Tiempo para asegurarse de que se detuvo

    // Cambiar sentido de giro
    sentidoHorario = !sentidoHorario;
  }

  // Resetear la espera de rebote cuando se suelta el botón
  if (digitalRead(botonPin) == LOW) {
    esperandoRebote = false;
  }

  // Movimiento normal en un sentido
  for (int i = 0; i < numSamples; i++) {
    int index1 = i;
    int index2, index3;

    if (sentidoHorario) {
      index2 = (i + numSamples / 3) % numSamples;       // +120°
      index3 = (i + 2 * numSamples / 3) % numSamples;   // +240°
    } else {
      index2 = (i + 2 * numSamples / 3) % numSamples;   // -120°
      index3 = (i + numSamples / 3) % numSamples;       // -240°
    }

    analogWrite(pwmPin1, sineTable[index1]);
    analogWrite(pwmPin2, sineTable[index2]);
    analogWrite(pwmPin3, sineTable[index3]);

    delayMicroseconds(100);
  }
}